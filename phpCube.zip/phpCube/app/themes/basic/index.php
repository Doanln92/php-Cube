<?php

/**
 * @author Doanln
 * @copyright 2017
 */

get_header();
?>
<article>
    <div class="container">
        <div class="message" style="padding:200px 10px">
            <div class="message-text">Welcome to phpCube</div>
        </div>
    </div>
</article>
<?php get_footer(); ?>