    <footer>
        <p>&copy; Copyright 2017 phpCube</p>
    </footer>
</body>
</html>
