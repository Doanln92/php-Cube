<?php

/**
 * @author Doanln
 * @copyright 2017
 */

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php _pagetitle(); ?></title>
    <link rel="stylesheet" href="<?php theme_url('css/style.css'); ?>" />
</head>
<body>
    <header><h1>phpCube</h1></header>
