<?php

/**
 * @author Doanln
 * @copyright 2017
 */
get_header();
?>
    <article class="full-width">
        <div class="container">
            <div class="error-message">
                <h2 class="message-text">404 - Page not found</h2>
            </div>
        </div>
    </article>
<?php get_footer(); ?>