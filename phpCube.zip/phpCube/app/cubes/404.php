<?php
add_pagetitle('404 - Page Not Found');
display("404");
?>