<?php

/**
 * @author Doanln
 * @copyright 2017
 */

add_pagetitle('PHPCube.com');

display('index');
?>