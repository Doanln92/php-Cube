<?php

/**
 * @author Doanln
 * @copyright 2017
 */

class Model{
    public $name;
    public function __construct($name = null) {
        $this->name = $name;
    }

}

?>