<?php

/**
 * @author Doanln
 * @copyright 2017
 */

function cube_start(){

    $config = get_config_var();
    cube::start($config);

}

function cube_finish(){
    
}
?>