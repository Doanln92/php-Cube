<?php

/**
 * @author Doanln
 * @copyright 2017
 */

function cube_start(){
    cube::start();
}

function cube_finish(){
    
}
?>