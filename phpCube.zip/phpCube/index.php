<?php

/**
 * @author Doanln
 * @copyright 2017
 */


require_once('config.php');
$config = get_config_var();
require_once(APPDIR.'load.php');





?>